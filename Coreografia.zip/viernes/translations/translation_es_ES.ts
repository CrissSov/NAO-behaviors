<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
    <context>
        <name>behavior_1/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hola</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Vamos a empezar con la sesión de ejercicios, por favor levanta los brazos así como lo hago yo</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say (1)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Muy bie, ahora vamos con el ejercicio 2</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say (2)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Perfecto, ahora sigamos con el ejercicio 3, sigueme al mismo tiempo</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say (3)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Llegamos al ultimo ejercicio, sigueme otra vez</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say (4)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Gracias por participar, lo hiciste muy bien, nos vemos pronto </source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
