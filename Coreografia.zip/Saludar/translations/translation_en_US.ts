<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>BienvenidaTerapia/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Bienvenido a tu rutina de ejercicios, vamos a comenzar</source>
            <comment>Text</comment>
            <translation type="obsolete">Bienvenido a tu rutina de ejercicios, vamos a comenzar</translation>
        </message>
        <message>
            <location filename="BienvenidaTerapia/behavior.xar" line="0"/>
            <source>Vamo a hacer una pausa a nuestra actividad académica y ejercitarnos un poco</source>
            <comment>Text</comment>
            <translation type="unfinished">Vamo a hacer una pausa a nuestra actividad académica y ejercitarnos un poco</translation>
        </message>
    </context>
    <context>
        <name>BienvenidaTerapia/behavior.xar:/Animated Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Por favor, sigue mis movimientos tal como lo hago yo</source>
            <comment>Text</comment>
            <translation type="obsolete">Por favor, sigue mis movimientos tal como lo hago yo</translation>
        </message>
        <message>
            <location filename="BienvenidaTerapia/behavior.xar" line="0"/>
            <source>Por favor, sigue mis movimientos al mismo tiempo</source>
            <comment>Text</comment>
            <translation type="unfinished">Por favor, sigue mis movimientos al mismo tiempo</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>un saludo a la bandera</source>
            <comment>Text</comment>
            <translation type="obsolete">un saludo a la bandera</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Un saludo para la Marina de Guerra, viva el Perú</source>
            <comment>Text</comment>
            <translation type="unfinished">Un saludo para la Marina de Guerra, viva el Perú</translation>
        </message>
    </context>
</TS>
