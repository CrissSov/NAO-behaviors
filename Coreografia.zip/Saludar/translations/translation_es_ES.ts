<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
    <context>
        <name>BienvenidaTerapia/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hola</translation>
        </message>
        <message>
            <location filename="BienvenidaTerapia/behavior.xar" line="0"/>
            <source>Vamo a hacer una pausa a nuestra actividad académica y ejercitarnos un poco</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>BienvenidaTerapia/behavior.xar:/Animated Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hola</translation>
        </message>
        <message>
            <location filename="BienvenidaTerapia/behavior.xar" line="0"/>
            <source>Por favor, sigue mis movimientos al mismo tiempo</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Un saludo para la Marina de Guerra, viva el Perú</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
