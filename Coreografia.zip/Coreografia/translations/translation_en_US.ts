<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Animated Say</name>
        <message>
            <source>¿Listo para el siguiente paso?</source>
            <comment>Text</comment>
            <translation type="obsolete">¿Listo para el siguiente paso?</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>¿Listo para el siguiente paso prohibido? Mira esto</source>
            <comment>Text</comment>
            <translation type="unfinished">¿Listo para el siguiente paso prohibido? Mira esto</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Mira ahora estos pasos</source>
            <comment>Text</comment>
            <translation type="unfinished">Mira ahora estos pasos</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say (2)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Qué bien lo hiciste, eso fue divertido</source>
            <comment>Text</comment>
            <translation type="unfinished">Qué bien lo hiciste, eso fue divertido</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>¿Lo tienes? Ahora hazlo conmigo</source>
            <comment>Text</comment>
            <translation type="unfinished">¿Lo tienes? Ahora hazlo conmigo</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>¿Que buen ritmo no crees? Ahora tu,sigueme</source>
            <comment>Text</comment>
            <translation type="unfinished">¿Que buen ritmo no crees? Ahora tu,sigueme</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>¿Que buen ritmo no crees? Ahora tu,sigueme</source>
            <comment>Text</comment>
            <translation type="unfinished">¿Que buen ritmo no crees? Ahora tu,sigueme</translation>
        </message>
    </context>
</TS>
